<?php $__env->startSection('content'); ?>

<?php $__env->startSection('content_title',__('Coberturas')); ?>

  <div class="row col-md-8">
    <form class="form-class" action="<?php echo e(route('pacient/healt_insurance/create')); ?>" method="get">
      <button class="btn btn-success pull-right" type="submit">
        <span class="fa fa-plus"></span> <?php echo e(__('Agregar')); ?>

      </button>
    </form>
  </div>

  <div class="row col-md-8"> &nbsp; </div>

  <div class="panel-group col-sm-12 col-md-8" id="accordion" role="tablist" aria-multiselectable="true" >

    <div class="panel panel-default">
      <?php $__currentLoopData = $healt_insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $healt_insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $i = $loop->index;
          ?>

          <div class="panel-heading" role="tab" id="heading-<?php echo e($i); ?>">
            <h5 class="panel-title">
              <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse-<?php echo e($i); ?>" aria-expanded="false" aria-controls="collapse-<?php echo e($i); ?>">
                <i class="fa fa-credit-card fa-2x" aria-hidden="true" style="margin-right:3px"></i>
                <?php echo e($healt_insurance->insurance); ?>

              </a>
            </h5>
          </div>

          <div id="collapse-<?php echo e($i); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading-<?php echo e($i); ?>">
            <div class="panel-body">
              <div class="form-group col-md-6">
                <label class="control-label"><?php echo e(__('Cobertura')); ?></label>
                <input readonly="true" name="cobertura" maxlength="100" type="text" required="required" class="form-control" placeholder="Cobertura" value="<?php echo e($healt_insurance->insurance); ?>" />
                <label class="control-label"><?php echo e(__('Plan')); ?></label>
                <input readonly="true" name="plan" maxlength="100" type="text" required="required" class="form-control" placeholder="Plan" value="<?php echo e($healt_insurance->plan); ?>" />
              </div>
              <div class="form-group col-md-6">
                <label class="control-label"><?php echo e(__('Tipo Contratacion')); ?></label>
                <input readonly="true" name="type_recruitment" maxlength="100" type="text" required="required" class="form-control" placeholder="Cobertura" value="<?php echo e($healt_insurance->type_recruitment); ?>"  />
                <label class="control-label"><?php echo e(__('Numero Afiliado')); ?></label>
                <input readonly="true" name="affiliate_number" maxlength="100" type="number" required="required" class="form-control" placeholder="Número Afiliado" value="<?php echo e($healt_insurance->affiliate_number); ?>"  />
              </div>
            </div>
          </div>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>