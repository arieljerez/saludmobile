<?php $__env->startSection('content'); ?>

<?php $__env->startSection('content_title',__('Coberturas: Agregar')); ?>


  <form class="form-class" method="post" action="<?php echo e(route('pacient/healt_insurance/store')); ?>">

      <div class="form-group col-md-4 col-md-offset-1">
        <label class="control-label"><?php echo e(__('Cobertura')); ?></label>
        <input name="insurance" maxlength="100" type="text" required="required" class="form-control" placeholder="Cobertura" value="<?php echo e(old('insurance')); ?>" />

        <label class="control-label"><?php echo e(__('Plan')); ?></label>
        <input name="plan" maxlength="100" type="text" required="required" class="form-control" placeholder="Plan" value="<?php echo e(old('plan')); ?>" />
      </div>

      <div class="form-group col-md-4 col-md-offset-1">
        <label class="control-label"><?php echo e(__('Tipo Contratacion')); ?></label>
        <input name="type_recruitment" maxlength="100" type="text" required="required" class="form-control" placeholder="Tipo Cobertura" value="<?php echo e(old('type_recruitment')); ?>"  />

        <label class="control-label"><?php echo e(__('Numero Afiliado')); ?></label>
        <input name="affiliate_number" maxlength="100" type="number" required="required" class="form-control" placeholder="Número Afiliado" value="<?php echo e(old('affiliate_number')); ?>"  />
      </div>

      <div class="row col-md-8 col-md-offset-1 pull-right">
        <a href="<?php echo e(route('pacient.healt_insurance.list')); ?>" class="btn btn-primary" type="button">
          <span class="fa fa-times"></span> <?php echo e(__('Cancelar')); ?>

        </a>
        <button class="btn btn-primary" type="submit">
          <span class="fa fa-plus"></span> <?php echo e(__('Aceptar')); ?>

        </button>
        <?php echo e(csrf_field()); ?>

      </div>

  </form>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>