<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
        <style>
            html, body {
                  background-color: #E2E2E0;
            }
            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }
        </style>
    </head>
    <body>
</br>
      <?php if(isset($error)): ?>
      <div class="alert alert-danger" role="alert">
        <?php echo e($error); ?>

      </div>
      <?php endif; ?>
</br>

        <div class="container">
          <div class = 'flex-center'>
              <img src="/logo-inicio.png" width="200">
          </div>
            <?php echo $__env->make('login_remote_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div> <!-- /container -->
</br>
        <div class="flex-center">
            <div class="content">
                <div class="links">
                    <a class="btn btn-link" href="/SaludMobile.apk">Bajar App Android</a>
                </div>

                <link rel="manifest" href="/manifest.json">
            </div>
        </div>
    </body>
</html>
